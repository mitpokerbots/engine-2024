#!/bin/bash

./build/pokerbot "$@"
